
(() => {
  const TUNNELS = ["trycloudflare.com","ngrok.io","localtunnel.me","serveo.net","pagekite.me"];
  function isIP(h){return /^\d{1,3}(\.\d{1,3}){3}$/.test(h)}
  function score(url){
    try{ const u=new URL(url); const host=u.hostname.toLowerCase(); let s=0; let r=[];
      if (TUNNELS.some(t=>host.endsWith(t))){ s+=60; r.push("tunnel_host"); }
      if (isIP(host)){ s+=45; r.push("ip_host"); }
      if (/xn--/.test(host) || /[^\x00-\x7F]/.test(host)){ s+=40; r.push("punycode_or_unicode"); }
      if (host.split(".").length>=4){ s+=20; r.push("many_subdomains"); }
      if (host.includes("-") && host.split("-").length>3){ s+=12; r.push("hyphenated"); }
      if (url.length>90){ s+=12; r.push("very_long"); }
      s=Math.max(0,Math.min(100,s)); return {s,r};
    }catch(e){return {s:80,r:["parse_error"]}}
  }
  function ensure(){ let e=document.getElementById("pg-lite"); if(e) return e; e=document.createElement("div"); e.id="pg-lite"; e.className="pg-bubble pg-ok"; e.innerHTML="<b class='title'>Checking…</b><div class='sub'></div><div class='u'></div>"; document.documentElement.appendChild(e); return e; }
  document.addEventListener("mouseover", (ev)=>{ const a=ev.target.closest("a[href]"); if(!a) return; const href=a.href; if(!/^https?:/i.test(href)) return; const res=score(href); const el=ensure(); el.style.left=(ev.pageX+12)+"px"; el.style.top=(ev.pageY+12)+"px"; el.style.display="block"; el.className="pg-bubble "+(res.s>=70?"pg-bad":res.s>=35?"pg-mid":"pg-ok"); el.querySelector(".title").textContent=(res.s>=70?"Phishing":res.s>=35?"Suspicious":"Safe")+" — "+res.s+"%"; el.querySelector(".sub").textContent=res.r.join(", "); el.querySelector(".u").textContent=href; }, true);
  document.addEventListener("mouseout", (ev)=>{ const a=ev.target.closest("a[href]"); if(!a) return; const el=document.getElementById("pg-lite"); if(el) el.style.display="none"; }, true);
  document.addEventListener("mousemove",(e)=>{ const el=document.getElementById("pg-lite"); if(el && el.style.display!=="none"){ el.style.left=(e.pageX+12)+"px"; el.style.top=(e.pageY+12)+"px"; } });
})();
